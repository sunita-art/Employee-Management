<?php
class Employee_model extends CI_Model {
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // Function to add a new employee
    public function add_employee($data) {
        $this->db->insert('employees', $data);
    }

    //Function to retrieve all employees
    public function get_employees() {
        return $this->db->get('employees')->result();
    }



    public function get_employee($id) {
        $this->db->where('id', $id);
        return $this->db->get('employees')->row();
    }

    // Function to update an employee
    public function edit_employee($id, $data) {
        $this->db->where('id', $id);
        $this->db->update('employees', $data);
    }


    public function delete_employee($id) {
        $this->db->where('id', $id);
        $this->db->delete('employees');
    }

}
?>
