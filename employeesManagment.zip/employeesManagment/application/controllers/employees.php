<?php
class Employees extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('Employee_model');
        $this->load->helper('url'); // Load URL helper to use base_url() function
         $this->load->helper('form');
         $this->load->library('form_validation'); 

    }

    public function index() {
        $data['employees'] = $this->Employee_model->get_employees();
        $this->load->view('list_employees', $data);
    }

    // Controller (Employees.php)
public function add_employee() {
    if ($this->input->post()) {
        // Form validation rules
            $this->form_validation->set_rules('first_name', 'First Name', 'required');
    
            $this->form_validation->set_rules('last_name', 'Last Name', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('mobile', 'Mobile', 'required');
            $this->form_validation->set_rules('address', 'Address', 'required');
            $this->form_validation->set_rules('gender', 'Gender', 'required');
            $this->form_validation->set_rules('hobby', 'Hobby', 'required');

        // Upload photo configuration
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['max_size'] = 2048; // 2MB
        $this->load->library('upload', $config);

        if ($this->form_validation->run()) {
            // If form validation passes
            if ($this->upload->do_upload('photo')) {
                // If file upload succeeds
                $data = $this->input->post();
                $upload_data = $this->upload->data(); // Get upload data
                $data['photo'] = $upload_data['file_name']; // Assign uploaded file name to data
              
                // Insert employee data into database
                $this->Employee_model->add_employee($data);

                redirect('employees');
            } else {
                // If file upload fails
                $error = $this->upload->display_errors();
                echo $error; // Display upload error
            }
        }
    }

    $this->load->view('add_employee');
}

// Controller (Employees.php)
public function edit_employee($employee_id) {
    if ($this->input->post()) {
        // Handle photo upload
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|jpeg|png';
        $config['max_size'] = 1024 * 5; // 5MB max size
        $config['overwrite'] = true; // Overwrite existing file
        $this->load->library('upload', $config);

        if ($this->upload->do_upload('photo')) {
            $upload_data = $this->upload->data();
            $data['photo'] = $upload_data['file_name'];
        } else {
            // Handle upload error
            $upload_error = $this->upload->display_errors();
            // Handle or display error message to the user
        }

        // Other form data
        $data['first_name'] = $this->input->post('first_name');
        $data['last_name'] = $this->input->post('last_name');
        $data['email'] = $this->input->post('email');
        $data['address'] = $this->input->post('address');
        $data['mobile'] = $this->input->post('mobile');
        $data['gender'] = $this->input->post('gender');
        $data['hobby'] = $this->input->post('hobby');
            
        // Update employee data in the database
        $this->Employee_model->edit_employee($employee_id, $data);

        redirect('employees');
    }

    $data['employee'] = $this->Employee_model->get_employee($employee_id);
    $this->load->view('edit_employee', $data);
}


// Controller (Employees.php)
public function delete_employee($employee_id) {

    $this->Employee_model->delete_employee($employee_id);
   
    redirect('employees');
}


    // Add other controller functions here (edit_employee, update_employee, delete_employee)
}
?>
