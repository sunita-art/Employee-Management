<!DOCTYPE html>
<html>
<head>
    <title>Add Employee</title>
     <style>
        .main {
            margin: 0 auto;
            width: 50%;
        }
        .error{
            color: red;
        }
    </style>
</head>
<body>
    <div class="main">
        <h1>Add Employee</h1>
    <?php //echo validation_errors(); ?>
    <?php echo form_open_multipart('employees/add_employee'); ?>
 
        <label for="first_name">First Name:</label><br>
       <input type="text" name="first_name">
     <?php echo form_error('first_name', '<div class="error">', '</div>'); ?><br>
         <label for="last_name">Last Name:</label><br>
        <input type="text" id="last_name" name="last_name"><br>
<?php echo form_error('last_name', '<div class="error">', '</div>'); ?>
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email"><br>
<?php echo form_error('email', '<div class="error">', '</div>'); ?><br>
        <label for="mobile">Mobile:</label><br>
        <input type="text" id="mobile" name="mobile"><br>
<?php echo form_error('mobile', '<div class="error">', '</div>'); ?>
        <label for="address">Address:</label><br>
        <textarea id="address" name="address"></textarea><br>
<?php echo form_error('address', '<div class="error">', '</div>'); ?>
        <label for="gender">Gender:</label><br>
        <input type="radio" id="gender" name="gender" value="Male"> Male
        <input type="radio" id="gender" name="gender" value="Female"> Female
        <?php echo form_error('gender', '<div class="error">', '</div>'); ?>
        <br>

        <label for="hobby">Hobby:</label><br>
        <input type="checkbox" id="hobby" name="hobby" value="Reading"> Reading
        <input type="checkbox" id="hobby" name="hobby" value="Traveling"> Traveling
        <input type="checkbox" id="hobby" name="hobby" value="Sports"> Sports<br>
<?php echo form_error('hobby', '<div class="error">', '</div>'); ?>
        <label for="photo">Photo:</label><br>
        <input type="file" id="photo" name="photo"><br> <br>
<?php echo form_error('photo', '<div class="error">', '</div>'); ?>
        <input type="submit" value="Submit">
    <?php echo form_close(); ?>
    </div>
</body>
</html>
