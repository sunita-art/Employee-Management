<!DOCTYPE html>
<html>
<head>
    <title>Update Employee</title>
    <style type="text/css">
        .main {
            margin: 0 auto;
            width:50%;
        }
    </style>
</head>
<body>
    <div class="main">
        <h1>Employee Management</h1>
    
    <?php echo form_open_multipart('employees/edit_employee/'.$employee->id); ?>

        <label for="first_name">First Name:</label><br>
        <input type="text" id="first_name" name="first_name" value="<?php echo $employee->first_name; ?>"><br>

        <label for="last_name">Last Name:</label><br>
        <input type="text" id="last_name" name="last_name" value="<?php echo $employee->last_name; ?>"><br>

        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" value="<?php echo $employee->email; ?>"><br>

        <label for="mobile">Mobile:</label><br>
        <input type="text" id="mobile" name="mobile" value="<?php echo $employee->mobile; ?>"><br>

        <label for="address">Address:</label><br>
        <textarea id="address" name="address"><?php echo $employee->address; ?></textarea><br>

        <label for="gender">Gender:</label><br>
        <input type="radio" id="gender_male" name="gender" value="Male" <?php echo ($employee->gender == 'Male') ? 'checked' : ''; ?>> Male
        <input type="radio" id="gender_female" name="gender" value="Female" <?php echo ($employee->gender == 'Female') ? 'checked' : ''; ?>> Female
        <input type="radio" id="gender_other" name="gender" value="Other" <?php echo ($employee->gender == 'Other') ? 'checked' : ''; ?>> Other<br>

        <label for="hobby">Hobby:</label><br>
        <input type="checkbox" id="hobby_reading" name="hobby" value="Reading" <?php echo $employee->hobby ? 'checked' : ''; ?>> Reading
        <input type="checkbox" id="hobby_traveling" name="hobby" value="Traveling" <?php echo $employee->hobby ? 'checked' : ''; ?>> Traveling
        <input type="checkbox" id="hobby_sports" name="hobby" value="Sports" <?php echo $employee->hobby ? 'checked' : ''; ?>> Sports<br>

        <label for="photo">Photo:</label><br>
        <input type="file" id="photo" name="photo"><br> 

        <input type="submit" value="Submit">
    <?php echo form_close(); ?>
    </div>
</body>
</html>
