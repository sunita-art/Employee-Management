<!DOCTYPE html>
<html>
<head>
    <title>List Employees</title>
</head>
<body>
    <h1>Employees Management</h1>
    <a href="<?php echo base_url('index.php/employees/add_employee'); ?>" style="color:green">Add New Employee</a>
<br><br>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Address</th>
            <th>Gender</th>
            <th>Hobby</th>
            <th>Photo</th>
            <th>Created Date</th>
            <th>Action</th>
        </tr>
        <?php foreach ($employees as $employee): ?>
        <tr>
            <td><?php echo $employee->id; ?></td>
            <td><?php echo $employee->first_name; ?></td>
            <td><?php echo $employee->last_name; ?></td>
            <td><?php echo $employee->email; ?></td>
            <td><?php echo $employee->mobile; ?></td>
            <td><?php echo $employee->address; ?></td>
            <td><?php echo $employee->gender; ?></td>
            <td><?php echo $employee->hobby; ?></td>
            <td><img src="<?php echo base_url('uploads/' . $employee->photo); ?>" width="50" height="50"></td>
            <td><?php echo $employee->created_date; ?></td>
            <td>
                <a href="<?php echo base_url('index.php/employees/edit_employee/'.$employee->id); ?>">Edit</a>
<a href="<?php echo base_url('index.php/employees/delete_employee/'.$employee->id); ?>" onclick="return confirm('Are you sure?')" style="color:red">Delete</a>

            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
